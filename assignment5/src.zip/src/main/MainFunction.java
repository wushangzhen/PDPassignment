package edu.neu.ccs.cs5010.assignment5;

import java.io.IOException;

/**
 * Main function for this program.
 */
public class MainFunction {

  public static void main(String[] args) throws IOException {
    new Compute().compute(args);
  }

}

